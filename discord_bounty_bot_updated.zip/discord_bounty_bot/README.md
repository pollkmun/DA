# Discord Bounty Bot — Updated

A `discord.py` slash-command bot using SQLite persistence.

## Setup

- Python 3.10+
- Create a Discord application and bot; enable **Server Members Intent** for role features.
- Invite it with `bot` and `applications.commands` scopes and the permissions it needs: Send Messages, Embed Links, Read Message History, Manage Roles. Put the bot's role above roles it assigns.
- Install dependencies: `pip install -r requirements.txt`
- Set `DISCORD_TOKEN` as an environment variable, then run `python bot.py`.

Windows PowerShell: `$env:DISCORD_TOKEN="YOUR_BOT_TOKEN"`

## Player commands

- `/balance [member]` — wallet and status
- `/bounty target amount` — spend money to increase another member's bounty
- `/relapsed [hunter]` — the target declares relapsed and must confirm with a button; hunter is optional
- `/nut` — increment nut count
- `/leaderboard metric` — money, bounty, score, jokers, nuts, hunt count, or rank by score
- `/claim_role_bonus` and `/payday` — role-based rewards
- `/jokers` — view joker definitions and your inventory
- `/use_joker target name` — use a joker you were given by an admin to multiply a bounty
- `/faction_join name`, `/faction_leave`, `/faction [name]` — faction membership and overview

Jokers are **not purchasable**. Administrators create them and grant them to members.

## Admin commands

- `/admin_help` — command list
- `/admin_role_reward role payday_money one_time_money` — configure role-based money rewards
- `/admin_joker_create name multiplier cost` — create/update a joker (the cost is retained for compatibility/display only)
- `/admin_joker_give member name quantity` — grant joker items
- `/admin_set_hunted_role role` — role given after a hunter claims a bounty
- `/admin_threshold_role metric threshold role` — auto roles based on points/score, bounty, hunt count, or top-N rank
- `/admin_remove_threshold_role metric threshold role` — remove an auto-role rule
- `/admin_give_money member amount` — grant money; displayed as `$`
- `/admin_set_bounty member amount` — set an unclaimed member's bounty
- `/admin_set_base_bounty amount` — default bounty for newly registered members
- `/admin_hunted target [hunter]` — admin-settle a claim without using `/relapsed`
- `/admin_reset_claimed member` — exceptional recovery; bounty remains zero
- `/admin_set_declaration_channel channel` — destination for declaration posts
- `/admin_set_declaration_message kind template condition [min_value] [max_value] [role]` — configure custom templates
- `/admin_clear_declaration_messages kind` — clear templates for one event type
- `/admin_set_command_channel command_name channel` / `/admin_clear_command_channel command_name` — restrict a slash command to a channel; admins bypass restrictions
- `/admin_faction_create name leader` — create a faction
- `/admin_leaderboard_refresh metric` — create/update the permanent leaderboard message

## Declaration templates

Kinds: `relapsed` (with hunter), `relapsed_no_hunter` (no hunter), and `admin_hunted` (admin settlement). Variables: `{relapsed}`, `{hunted}`, `{hunter}`, `{bounty}`, `{points}`, `{rank}`. The relapsed/hunted variables both mention the target. `{hunter}` mentions the hunter or displays `No hunter`. Configure a declaration channel first.

Templates can be conditioned on rank range, role, bounty range, or points/score range. If more than one rule matches, priority is **rank > role > bounty/points range > default**. The newest rule wins among rules with the same priority.

## Behavior notes

- `/relapsed` requires explicit confirmation. With a hunter, the hunter receives score equal to the claimed bounty, the target's bounty becomes permanently zero, and the hunter's hunt count increments. Without a hunter, no score is transferred; the target is marked settled and their bounty is locked at zero.
- The target cannot receive bounty increases or joker multipliers after being settled.
- The permanent leaderboard updates after relevant actions and on a 60-second background refresh while the bot is online. Rank-based roles are periodically reconciled as well.
- Factions are self-join/self-leave; creation is admin-only.
- Channel restrictions are configured by slash-command name, e.g. `relapsed`. Administrators bypass these restrictions.
- SQLite data persists in `bounty_bot.sqlite3`; back it up regularly. Existing databases are migrated automatically for the new fields/tables.
