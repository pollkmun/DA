import os
import sqlite3
import time
from typing import Optional
import re

import discord
from discord import app_commands
from discord.ext import commands, tasks

TOKEN = os.getenv("DISCORD_TOKEN")
DB_PATH = os.getenv("BOT_DB_PATH", "bounty_bot.sqlite3")

intents = discord.Intents.default()
intents.members = True
bot = commands.Bot(command_prefix="!", intents=intents)

CURRENCIES = {"money", "bounty", "score", "jokers", "nuts", "hunt_count", "rank"}
MEDALS = ["🥇", "🥈", "🥉"]
PAYDAY_COOLDOWN = 24 * 60 * 60


def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
            money INTEGER NOT NULL DEFAULT 0,
            bounty INTEGER NOT NULL DEFAULT 0,
            score INTEGER NOT NULL DEFAULT 0,
            nuts INTEGER NOT NULL DEFAULT 0,
            hunted INTEGER NOT NULL DEFAULT 0,
            hunted_by INTEGER,
            hunt_count INTEGER NOT NULL DEFAULT 0,
            faction TEXT,
            last_payday INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY (guild_id, user_id)
        );
        CREATE TABLE IF NOT EXISTS inventory (
            guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
            joker_name TEXT NOT NULL, quantity INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY (guild_id, user_id, joker_name)
        );
        CREATE TABLE IF NOT EXISTS jokers (
            guild_id INTEGER NOT NULL, name TEXT NOT NULL,
            multiplier REAL NOT NULL, cost INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY (guild_id, name)
        );
        CREATE TABLE IF NOT EXISTS role_rewards (
            guild_id INTEGER NOT NULL, role_id INTEGER NOT NULL,
            payday_money INTEGER NOT NULL DEFAULT 0,
            one_time_money INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY (guild_id, role_id)
        );
        CREATE TABLE IF NOT EXISTS role_claims (
            guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL, role_id INTEGER NOT NULL,
            PRIMARY KEY (guild_id, user_id, role_id)
        );
        CREATE TABLE IF NOT EXISTS threshold_roles (
            guild_id INTEGER NOT NULL, metric TEXT NOT NULL, threshold INTEGER NOT NULL,
            role_id INTEGER NOT NULL,
            PRIMARY KEY (guild_id, metric, threshold, role_id)
        );
        CREATE TABLE IF NOT EXISTS settings (
            guild_id INTEGER NOT NULL, key TEXT NOT NULL, value TEXT NOT NULL,
            PRIMARY KEY (guild_id, key)
        );
        CREATE TABLE IF NOT EXISTS factions (
            guild_id INTEGER NOT NULL, name TEXT NOT NULL, leader_id INTEGER NOT NULL,
            PRIMARY KEY (guild_id, name)
        );
        CREATE TABLE IF NOT EXISTS declaration_rules (
            id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER NOT NULL,
            kind TEXT NOT NULL, condition_type TEXT NOT NULL DEFAULT 'default',
            min_value INTEGER, max_value INTEGER, role_id INTEGER,
            template TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS leaderboard_messages (
            guild_id INTEGER PRIMARY KEY, channel_id INTEGER NOT NULL, message_id INTEGER NOT NULL,
            metric TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS leaderboard_snapshots (
            guild_id INTEGER NOT NULL, metric TEXT NOT NULL, snapshot_at INTEGER NOT NULL,
            payload TEXT NOT NULL,
            PRIMARY KEY (guild_id, metric)
        );
        """)
        # Safe migrations for databases created by earlier versions.
        columns = {r["name"] for r in c.execute("PRAGMA table_info(users)").fetchall()}
        if "hunt_count" not in columns:
            c.execute("ALTER TABLE users ADD COLUMN hunt_count INTEGER NOT NULL DEFAULT 0")
        if "faction" not in columns:
            c.execute("ALTER TABLE users ADD COLUMN faction TEXT")


def ensure_user(guild_id: int, user_id: int):
    with db() as c:
        base = setting(guild_id, "base_bounty", "0")
        c.execute("INSERT OR IGNORE INTO users(guild_id,user_id,bounty) VALUES(?,?,?)", (guild_id, user_id, int(base) if base.isdigit() else 0))


def get_user(guild_id: int, user_id: int):
    ensure_user(guild_id, user_id)
    with db() as c:
        return c.execute("SELECT * FROM users WHERE guild_id=? AND user_id=?",
                         (guild_id, user_id)).fetchone()


def setting(guild_id: int, key: str, default: str = "") -> str:
    with db() as c:
        row = c.execute("SELECT value FROM settings WHERE guild_id=? AND key=?",
                        (guild_id, key)).fetchone()
    return row["value"] if row else default


def set_setting(guild_id: int, key: str, value: str):
    with db() as c:
        c.execute("""INSERT INTO settings(guild_id,key,value) VALUES(?,?,?)
                     ON CONFLICT(guild_id,key) DO UPDATE SET value=excluded.value""",
                  (guild_id, key, value))


async def sync_roles(member: discord.Member):
    """Apply the highest eligible role per metric. Existing bot-managed threshold roles are removed first."""
    gid, uid = member.guild.id, member.id
    with db() as c:
        mappings = c.execute("SELECT metric,threshold,role_id FROM threshold_roles WHERE guild_id=?",
                             (gid,)).fetchall()
    if not mappings:
        return
    user = get_user(gid, uid)
    managed_ids = {r["role_id"] for r in mappings}
    desired = set()
    score_rows = leaderboard_rows(gid, "score", 100000)
    rank = next((i + 1 for i, row in enumerate(score_rows) if row["user_id"] == uid), len(score_rows) + 1)
    for metric in ("score", "bounty", "hunt_count", "rank"):
        if metric == "rank":
            eligible = [r for r in mappings if r["metric"] == metric and rank <= r["threshold"]]
            chosen = min(eligible, key=lambda x: x["threshold"]) if eligible else None
        else:
            eligible = [r for r in mappings if r["metric"] == metric and user[metric] >= r["threshold"]]
            chosen = max(eligible, key=lambda x: x["threshold"]) if eligible else None
        if chosen:
            desired.add(chosen["role_id"])
    to_remove = [r for r in member.roles if r.id in managed_ids and r.id not in desired]
    to_add = [member.guild.get_role(rid) for rid in desired if member.guild.get_role(rid)
              and member.guild.get_role(rid) not in member.roles]
    try:
        if to_remove:
            await member.remove_roles(*to_remove, reason="Bounty bot threshold role update")
        if to_add:
            await member.add_roles(*to_add, reason="Bounty bot threshold role update")
    except discord.Forbidden:
        pass


async def refresh_roles_for(guild: discord.Guild, user_id: int):
    member = guild.get_member(user_id)
    if member:
        await sync_roles(member)


def leaderboard_rows(guild_id: int, metric: str, limit: int = 10):
    if metric not in CURRENCIES:
        raise ValueError("Unsupported leaderboard metric")
    if metric == "rank":
        with db() as c:
            rows = c.execute("SELECT user_id, score AS value FROM users WHERE guild_id=? ORDER BY score DESC, user_id ASC LIMIT ?", (guild_id, limit)).fetchall()
        return [dict(user_id=row["user_id"], value=index + 1) for index, row in enumerate(rows)]
    column = "jokers" if metric == "jokers" else ("hunt_count" if metric == "hunt_count" else metric)
    if column == "jokers":
        query = """SELECT u.user_id, COALESCE(SUM(i.quantity),0) AS value
                   FROM users u LEFT JOIN inventory i
                   ON u.guild_id=i.guild_id AND u.user_id=i.user_id
                   WHERE u.guild_id=? GROUP BY u.user_id ORDER BY value DESC LIMIT ?"""
    else:
        query = f"SELECT user_id, {column} AS value FROM users WHERE guild_id=? ORDER BY {column} DESC LIMIT ?"
    with db() as c:
        return c.execute(query, (guild_id, limit)).fetchall()


def leaderboard_embed(guild: discord.Guild, metric: str, rows=None):
    rows = rows if rows is not None else leaderboard_rows(guild.id, metric, 10)
    labels = {"money": "Money", "bounty": "Bounty", "score": "Score", "jokers": "Jokers", "nuts": "Nuts", "hunt_count": "Hunt Count", "rank": "Rank"}
    embed = discord.Embed(title=f"🏆 {labels[metric]} Leaderboard", color=discord.Color.gold())
    if not rows:
        embed.description = "No scores yet."
        return embed
    lines = []
    for index, row in enumerate(rows):
        member = guild.get_member(row["user_id"])
        name = member.display_name if member else f"Unknown user ({row['user_id']})"
        medal = MEDALS[index] if index < 3 else f"**{index + 1}.**"
        shown_value = f"{row['value']:,}$" if metric == "money" else f"{row['value']:,}"
        lines.append(f"{medal} {name} — **{shown_value}**")
    embed.description = "\n".join(lines)
    first_member = guild.get_member(rows[0]["user_id"])
    if first_member:
        embed.set_thumbnail(url=first_member.display_avatar.url)
    embed.set_footer(text="Top 3 receive medals • Use /leaderboard to change category")
    return embed


async def update_saved_leaderboard(guild: discord.Guild):
    with db() as c:
        row = c.execute("SELECT * FROM leaderboard_messages WHERE guild_id=?", (guild.id,)).fetchone()
    if not row:
        return
    channel = guild.get_channel(row["channel_id"])
    if not isinstance(channel, discord.abc.Messageable):
        return
    try:
        message = await channel.fetch_message(row["message_id"])
        await message.edit(embed=leaderboard_embed(guild, row["metric"]))
    except (discord.NotFound, discord.Forbidden, discord.HTTPException):
        pass


async def safe_defer(interaction: discord.Interaction):
    if not interaction.response.is_done():
        await interaction.response.defer(ephemeral=True)


@bot.event
async def on_ready():
    init_db()
    if not leaderboard_auto_refresh.is_running():
        leaderboard_auto_refresh.start()
    try:
        synced = await bot.tree.sync()
        print(f"Logged in as {bot.user}; synced {len(synced)} slash commands.")
    except Exception as e:
        print("Slash command sync failed:", e)


@bot.event
async def on_member_join(member: discord.Member):
    ensure_user(member.guild.id, member.id)
    # One-time role rewards are claimed using /claim_role_bonus to avoid silently granting money on joins.


@bot.tree.command(name="balance", description="View your or another member's economy balance.")
@app_commands.describe(member="Member to inspect (defaults to you)")
async def balance(interaction: discord.Interaction, member: Optional[discord.Member] = None):
    member = member or interaction.user
    u = get_user(interaction.guild_id, member.id)
    with db() as c:
        jokers = c.execute("SELECT COALESCE(SUM(quantity),0) AS n FROM inventory WHERE guild_id=? AND user_id=?",
                           (interaction.guild_id, member.id)).fetchone()["n"]
    embed = discord.Embed(title=f"{member.display_name}'s Wallet", color=discord.Color.blurple())
    embed.set_thumbnail(url=member.display_avatar.url)
    embed.add_field(name="💰 Money", value=f"{u['money']:,}$", inline=True)
    embed.add_field(name="🎯 Bounty", value=f"{u['bounty']:,}", inline=True)
    embed.add_field(name="🏆 Score", value=f"{u['score']:,}", inline=True)
    embed.add_field(name="🃏 Jokers", value=f"{jokers:,}", inline=True)
    embed.add_field(name="🥜 Nuts", value=f"{u['nuts']:,}", inline=True)
    embed.add_field(name="Status", value="Claimed / bounty locked" if u["hunted"] else "Active", inline=False)
    await interaction.response.send_message(embed=embed)


@bot.tree.command(name="bounty", description="Spend money to add to a member's bounty.")
@app_commands.describe(target="Member whose bounty to increase", amount="Money to spend")
async def bounty(interaction: discord.Interaction, target: discord.Member, amount: app_commands.Range[int, 1, 1000000000]):
    if target.bot or target.id == interaction.user.id:
        return await interaction.response.send_message("Choose another non-bot member.", ephemeral=True)
    t = get_user(interaction.guild_id, target.id)
    if t["hunted"]:
        return await interaction.response.send_message("That member's bounty is permanently locked at 0.", ephemeral=True)
    me = get_user(interaction.guild_id, interaction.user.id)
    if me["money"] < amount:
        return await interaction.response.send_message("You don't have enough money.", ephemeral=True)
    with db() as c:
        c.execute("UPDATE users SET money=money-? WHERE guild_id=? AND user_id=?",
                  (amount, interaction.guild_id, interaction.user.id))
        c.execute("UPDATE users SET bounty=bounty+? WHERE guild_id=? AND user_id=?",
                  (amount, interaction.guild_id, target.id))
    await refresh_roles_for(interaction.guild, target.id)
    await interaction.response.send_message(f"Added **{amount:,}** bounty to {target.mention}.")
    await update_saved_leaderboard(interaction.guild)


class RelapsedConfirmView(discord.ui.View):
    def __init__(self, target_id: int, hunter: Optional[discord.Member]):
        super().__init__(timeout=60)
        self.target_id = target_id
        self.hunter = hunter
        self.done = False

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.target_id:
            await interaction.response.send_message("Only the member who started this declaration can confirm it.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Confirm relapsed", style=discord.ButtonStyle.danger)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.done:
            return await interaction.response.send_message("This declaration has already been handled.", ephemeral=True)
        self.done = True
        target = interaction.guild.get_member(self.target_id)
        hunter = self.hunter
        target_data = get_user(interaction.guild_id, self.target_id)
        if target_data["hunted"]:
            return await interaction.response.edit_message(content="This member was already claimed.", view=None)
        claimed = target_data["bounty"]
        if hunter and (hunter.bot or hunter.id == target.id):
            return await interaction.response.edit_message(content="Choose another human member as hunter.", view=None)
        if hunter and claimed <= 0:
            return await interaction.response.edit_message(content="There is no bounty to claim. Use relapsed without a hunter if this is just a declaration.", view=None)
        with db() as c:
            if hunter:
                c.execute("UPDATE users SET bounty=0,hunted=1,hunted_by=? WHERE guild_id=? AND user_id=?",
                          (hunter.id, interaction.guild_id, target.id))
                c.execute("UPDATE users SET score=score+?,hunt_count=hunt_count+1 WHERE guild_id=? AND user_id=?",
                          (claimed, interaction.guild_id, hunter.id))
            else:
                # A no-hunter declaration records the relapsed status but does not claim/transfer bounty.
                c.execute("UPDATE users SET hunted=1,hunted_by=NULL,bounty=0 WHERE guild_id=? AND user_id=?",
                          (interaction.guild_id, target.id))
        if hunter:
            role_id = setting(interaction.guild_id, "hunted_role_id")
            role = interaction.guild.get_role(int(role_id)) if role_id.isdigit() else None
            if role:
                try: await target.add_roles(role, reason="Bounty claimed")
                except discord.Forbidden: pass
            await refresh_roles_for(interaction.guild, hunter.id)
        await refresh_roles_for(interaction.guild, target.id)
        await publish_declaration(interaction.guild, target, hunter, claimed, "relapsed" if hunter else "relapsed_no_hunter")
        await update_saved_leaderboard(interaction.guild)
        text = (f"{hunter.mention} claimed {target.mention}'s **{claimed:,}** bounty; "
                f"{claimed:,} score transferred to the hunter. Bounty is now locked at 0." if hunter else
                f"{target.mention} was marked as relapsed without a hunter. Bounty set to 0 and locked.")
        await interaction.response.edit_message(content=text, view=None)

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.done = True
        await interaction.response.edit_message(content="Relapsed declaration cancelled.", view=None)


@bot.tree.command(name="relapsed", description="Declare that you relapsed; optionally tag the hunter, then confirm.")
@app_commands.describe(hunter="Optional member claiming your bounty; leave empty for no hunter")
async def relapsed(interaction: discord.Interaction, hunter: Optional[discord.Member] = None):
    target_data = get_user(interaction.guild_id, interaction.user.id)
    if target_data["hunted"]:
        return await interaction.response.send_message("Your bounty/status has already been settled.", ephemeral=True)
    if hunter and target_data["bounty"] <= 0:
        return await interaction.response.send_message("You have no bounty to claim. Leave hunter empty for a no-hunter declaration.", ephemeral=True)
    view = RelapsedConfirmView(interaction.user.id, hunter)
    detail = f"Hunter: {hunter.mention}; bounty to claim: **{target_data['bounty']:,}**." if hunter else "No hunter involved; this uses the no-hunter declaration and locks your bounty at 0."
    await interaction.response.send_message(f"Confirm your relapsed declaration? {detail}", view=view, ephemeral=True)


@bot.tree.command(name="nut", description="Increase your nut count by exactly one.")
async def nut(interaction: discord.Interaction):
    with db() as c:
        c.execute("UPDATE users SET nuts=nuts+1 WHERE guild_id=? AND user_id=?",
                  (interaction.guild_id, interaction.user.id))
    u = get_user(interaction.guild_id, interaction.user.id)
    await interaction.response.send_message(f"🥜 Nut count increased to **{u['nuts']}**.")
    await update_saved_leaderboard(interaction.guild)


@bot.tree.command(name="leaderboard", description="View a leaderboard by currency.")
@app_commands.choices(metric=[
    app_commands.Choice(name="Money", value="money"),
    app_commands.Choice(name="Bounty", value="bounty"),
    app_commands.Choice(name="Score", value="score"),
    app_commands.Choice(name="Jokers", value="jokers"),
    app_commands.Choice(name="Nuts", value="nuts"),
    app_commands.Choice(name="Hunt count", value="hunt_count"),
    app_commands.Choice(name="Rank by score", value="rank"),
])
async def leaderboard(interaction: discord.Interaction, metric: app_commands.Choice[str]):
    await interaction.response.send_message(embed=leaderboard_embed(interaction.guild, metric.value))


@bot.tree.command(name="claim_role_bonus", description="Claim eligible one-time bonuses from your roles.")
async def claim_role_bonus(interaction: discord.Interaction):
    total = 0
    claimed_roles = []
    with db() as c:
        rewards = c.execute("SELECT * FROM role_rewards WHERE guild_id=? AND one_time_money>0",
                            (interaction.guild_id,)).fetchall()
        for reward in rewards:
            if interaction.guild.get_role(reward["role_id"]) in interaction.user.roles:
                exists = c.execute("SELECT 1 FROM role_claims WHERE guild_id=? AND user_id=? AND role_id=?",
                                   (interaction.guild_id, interaction.user.id, reward["role_id"])).fetchone()
                if not exists:
                    c.execute("INSERT INTO role_claims(guild_id,user_id,role_id) VALUES(?,?,?)",
                              (interaction.guild_id, interaction.user.id, reward["role_id"]))
                    total += reward["one_time_money"]
                    claimed_roles.append(reward["role_id"])
        if total:
            c.execute("UPDATE users SET money=money+? WHERE guild_id=? AND user_id=?",
                      (total, interaction.guild_id, interaction.user.id))
    if not total:
        return await interaction.response.send_message("No unclaimed role bonuses are available.", ephemeral=True)
    await interaction.response.send_message(f"🎁 You claimed **{total:,}$** from your role bonus(es).")


@bot.tree.command(name="payday", description="Claim recurring money rewards for your roles (24-hour cooldown).")
async def payday(interaction: discord.Interaction):
    u = get_user(interaction.guild_id, interaction.user.id)
    now = int(time.time())
    wait = PAYDAY_COOLDOWN - (now - u["last_payday"])
    if wait > 0:
        return await interaction.response.send_message(
            f"You can claim payday again in **{wait // 3600}h {(wait % 3600) // 60}m**.", ephemeral=True)
    total = 0
    with db() as c:
        rewards = c.execute("SELECT * FROM role_rewards WHERE guild_id=? AND payday_money>0",
                            (interaction.guild_id,)).fetchall()
        for reward in rewards:
            role = interaction.guild.get_role(reward["role_id"])
            if role and role in interaction.user.roles:
                total += reward["payday_money"]
        c.execute("UPDATE users SET money=money+?,last_payday=? WHERE guild_id=? AND user_id=?",
                  (total, now, interaction.guild_id, interaction.user.id))
    await interaction.response.send_message(f"💰 Payday: you received **{total:,}$**.")


@bot.tree.command(name="jokers", description="View available jokers and your inventory.")
async def jokers(interaction: discord.Interaction):
    with db() as c:
        available = c.execute("SELECT name,multiplier,cost FROM jokers WHERE guild_id=? ORDER BY name",
                              (interaction.guild_id,)).fetchall()
        owned = c.execute("SELECT joker_name,quantity FROM inventory WHERE guild_id=? AND user_id=? AND quantity>0",
                          (interaction.guild_id, interaction.user.id)).fetchall()
    embed = discord.Embed(title="🃏 Jokers", color=discord.Color.purple())
    embed.add_field(name="Available", value="\n".join(
        f"**{r['name']}** — ×{r['multiplier']:g} (admin-granted only)" for r in available
    ) or "No jokers created yet.", inline=False)
    embed.add_field(name="Your inventory", value="\n".join(
        f"**{r['joker_name']}** × {r['quantity']}" for r in owned
    ) or "No jokers owned.", inline=False)
    await interaction.response.send_message(embed=embed, ephemeral=True)


@bot.tree.command(name="use_joker", description="Multiply a member's bounty using one of your jokers.")
async def use_joker(interaction: discord.Interaction, target: discord.Member, name: str):
    if target.bot or target.id == interaction.user.id:
        return await interaction.response.send_message("Choose another non-bot member.", ephemeral=True)
    t = get_user(interaction.guild_id, target.id)
    if t["hunted"] or t["bounty"] <= 0:
        return await interaction.response.send_message("That bounty is locked or is currently 0.", ephemeral=True)
    with db() as c:
        joker = c.execute("SELECT * FROM jokers WHERE guild_id=? AND name=? COLLATE NOCASE",
                          (interaction.guild_id, name)).fetchone()
        inv = c.execute("SELECT quantity FROM inventory WHERE guild_id=? AND user_id=? AND joker_name=?",
                        (interaction.guild_id, interaction.user.id, joker["name"] if joker else name)).fetchone()
    if not joker or not inv or inv["quantity"] < 1:
        return await interaction.response.send_message("You don't own that joker.", ephemeral=True)
    old = t["bounty"]
    new = int(old * joker["multiplier"])
    increase = new - old
    with db() as c:
        c.execute("UPDATE inventory SET quantity=quantity-1 WHERE guild_id=? AND user_id=? AND joker_name=?",
                  (interaction.guild_id, interaction.user.id, joker["name"]))
        c.execute("UPDATE users SET bounty=? WHERE guild_id=? AND user_id=?",
                  (new, interaction.guild_id, target.id))
    await refresh_roles_for(interaction.guild, target.id)
    await interaction.response.send_message(
        f"🃏 {interaction.user.mention} used **{joker['name']} (×{joker['multiplier']:g})** on {target.mention}: "
        f"bounty **{old:,} → {new:,}** (+{increase:,}).")
    await update_saved_leaderboard(interaction.guild)


def admin_only():
    return app_commands.checks.has_permissions(administrator=True)


@bot.tree.command(name="admin_role_reward", description="Admin: set role payday and one-time money rewards.")
@admin_only()
async def admin_role_reward(interaction: discord.Interaction, role: discord.Role,
                            payday_money: app_commands.Range[int, 0, 1000000000],
                            one_time_money: app_commands.Range[int, 0, 1000000000]):
    with db() as c:
        c.execute("""INSERT INTO role_rewards(guild_id,role_id,payday_money,one_time_money) VALUES(?,?,?,?)
                     ON CONFLICT(guild_id,role_id) DO UPDATE SET payday_money=excluded.payday_money,
                     one_time_money=excluded.one_time_money""",
                  (interaction.guild_id, role.id, payday_money, one_time_money))
    await interaction.response.send_message(
        f"Configured {role.mention}: payday **{payday_money:,}**, one-time bonus **{one_time_money:,}**. "
        "Members use `/claim_role_bonus` and `/payday`.", ephemeral=True)


@bot.tree.command(name="admin_joker_create", description="Admin: create or update a joker and its multiplier/cost.")
@admin_only()
async def admin_joker_create(interaction: discord.Interaction, name: str,
                             multiplier: app_commands.Range[float, 1.01, 1000.0],
                             cost: app_commands.Range[int, 0, 1000000000]):
    name = name.strip()[:50]
    with db() as c:
        c.execute("""INSERT INTO jokers(guild_id,name,multiplier,cost) VALUES(?,?,?,?)
                     ON CONFLICT(guild_id,name) DO UPDATE SET multiplier=excluded.multiplier,cost=excluded.cost""",
                  (interaction.guild_id, name, multiplier, cost))
    await interaction.response.send_message(
        f"Joker **{name}** saved: ×{multiplier:g}, cost **{cost:,}$**.", ephemeral=True)


@bot.tree.command(name="admin_joker_give", description="Admin: give a member joker items.")
@admin_only()
async def admin_joker_give(interaction: discord.Interaction, member: discord.Member, name: str,
                           quantity: app_commands.Range[int, 1, 100000]):
    with db() as c:
        joker = c.execute("SELECT name FROM jokers WHERE guild_id=? AND name=? COLLATE NOCASE",
                          (interaction.guild_id, name)).fetchone()
        if not joker:
            return await interaction.response.send_message("Create that joker first.", ephemeral=True)
        c.execute("""INSERT INTO inventory(guild_id,user_id,joker_name,quantity) VALUES(?,?,?,?)
                     ON CONFLICT(guild_id,user_id,joker_name) DO UPDATE SET quantity=quantity+excluded.quantity""",
                  (interaction.guild_id, member.id, joker["name"], quantity))
    await interaction.response.send_message(f"Gave {member.mention} **{quantity} × {joker['name']}**.", ephemeral=True)


@bot.tree.command(name="admin_set_hunted_role", description="Admin: set the role given to members whose bounty is claimed.")
@admin_only()
async def admin_set_hunted_role(interaction: discord.Interaction, role: discord.Role):
    set_setting(interaction.guild_id, "hunted_role_id", str(role.id))
    await interaction.response.send_message(f"Hunted role set to {role.mention}.", ephemeral=True)


@bot.tree.command(name="admin_threshold_role", description="Admin: add a role threshold for score or bounty.")
@admin_only()
@app_commands.choices(metric=[
    app_commands.Choice(name="Score / points", value="score"),
    app_commands.Choice(name="Bounty", value="bounty"),
    app_commands.Choice(name="Hunt count", value="hunt_count"),
    app_commands.Choice(name="Rank (top N)", value="rank"),
])
async def admin_threshold_role(interaction: discord.Interaction, metric: app_commands.Choice[str],
                               threshold: app_commands.Range[int, 0, 1000000000], role: discord.Role):
    with db() as c:
        c.execute("INSERT OR IGNORE INTO threshold_roles(guild_id,metric,threshold,role_id) VALUES(?,?,?,?)",
                  (interaction.guild_id, metric.value, threshold, role.id))
    await interaction.response.send_message(
        f"Added automatic role rule: {metric.value} ≥ {threshold:,} → {role.mention}.", ephemeral=True)
    await refresh_roles_for(interaction.guild, interaction.user.id)


@bot.tree.command(name="admin_remove_threshold_role", description="Admin: remove a score/bounty role threshold.")
@admin_only()
@app_commands.choices(metric=[
    app_commands.Choice(name="Score / points", value="score"),
    app_commands.Choice(name="Bounty", value="bounty"),
    app_commands.Choice(name="Hunt count", value="hunt_count"),
    app_commands.Choice(name="Rank (top N)", value="rank"),
])
async def admin_remove_threshold_role(interaction: discord.Interaction, metric: app_commands.Choice[str],
                                      threshold: app_commands.Range[int, 0, 1000000000], role: discord.Role):
    with db() as c:
        c.execute("DELETE FROM threshold_roles WHERE guild_id=? AND metric=? AND threshold=? AND role_id=?",
                  (interaction.guild_id, metric.value, threshold, role.id))
    await interaction.response.send_message("Threshold rule removed.", ephemeral=True)


@bot.tree.command(name="admin_give_money", description="Admin: grant money to a member.")
@admin_only()
async def admin_give_money(interaction: discord.Interaction, member: discord.Member,
                           amount: app_commands.Range[int, 1, 1000000000]):
    ensure_user(interaction.guild_id, member.id)
    with db() as c:
        c.execute("UPDATE users SET money=money+? WHERE guild_id=? AND user_id=?",
                  (amount, interaction.guild_id, member.id))
    await interaction.response.send_message(f"Granted **{amount:,}$** to {member.mention}.", ephemeral=True)


@bot.tree.command(name="admin_set_bounty", description="Admin: set a member's bounty (cannot unlock a claimed bounty).")
@admin_only()
async def admin_set_bounty(interaction: discord.Interaction, member: discord.Member,
                           amount: app_commands.Range[int, 0, 1000000000]):
    u = get_user(interaction.guild_id, member.id)
    if u["hunted"] and amount > 0:
        return await interaction.response.send_message(
            "This member's bounty was already claimed and is permanently locked at 0.", ephemeral=True)
    with db() as c:
        c.execute("UPDATE users SET bounty=? WHERE guild_id=? AND user_id=?",
                  (amount, interaction.guild_id, member.id))
    await refresh_roles_for(interaction.guild, member.id)
    await interaction.response.send_message(f"Set {member.mention}'s bounty to **{amount:,}**.", ephemeral=True)


@bot.tree.command(name="admin_reset_claimed", description="Admin: reset a member's claimed status (exceptional recovery only).")
@admin_only()
async def admin_reset_claimed(interaction: discord.Interaction, member: discord.Member):
    with db() as c:
        c.execute("UPDATE users SET hunted=0,hunted_by=NULL,bounty=0 WHERE guild_id=? AND user_id=?",
                  (interaction.guild_id, member.id))
    await interaction.response.send_message(
        f"{member.mention}'s claimed flag was reset, but bounty remains 0. This is an admin override.", ephemeral=True)


@bot.tree.command(name="admin_leaderboard_refresh", description="Admin: create or update a permanent leaderboard message in this channel.")
@admin_only()
@app_commands.choices(metric=[
    app_commands.Choice(name="Money", value="money"),
    app_commands.Choice(name="Bounty", value="bounty"),
    app_commands.Choice(name="Score", value="score"),
    app_commands.Choice(name="Jokers", value="jokers"),
    app_commands.Choice(name="Nuts", value="nuts"),
    app_commands.Choice(name="Hunt count", value="hunt_count"),
    app_commands.Choice(name="Rank by score", value="rank"),
])
async def admin_leaderboard_refresh(interaction: discord.Interaction, metric: app_commands.Choice[str]):
    await interaction.response.defer(ephemeral=True)
    with db() as c:
        row = c.execute("SELECT * FROM leaderboard_messages WHERE guild_id=?",
                        (interaction.guild_id,)).fetchone()
    embed = leaderboard_embed(interaction.guild, metric.value)
    if row:
        channel = interaction.guild.get_channel(row["channel_id"])
        try:
            message = await channel.fetch_message(row["message_id"]) if channel else None
            if message:
                await message.edit(embed=embed)
                with db() as c:
                    c.execute("UPDATE leaderboard_messages SET metric=? WHERE guild_id=?",
                              (metric.value, interaction.guild_id))
                return await interaction.followup.send("Permanent leaderboard updated.", ephemeral=True)
        except (discord.NotFound, discord.Forbidden, discord.HTTPException):
            pass
    if not isinstance(interaction.channel, discord.abc.Messageable):
        return await interaction.followup.send("Run this command in a text channel.", ephemeral=True)
    message = await interaction.channel.send(embed=embed)
    with db() as c:
        c.execute("""INSERT INTO leaderboard_messages(guild_id,channel_id,message_id,metric) VALUES(?,?,?,?)
                     ON CONFLICT(guild_id) DO UPDATE SET channel_id=excluded.channel_id,
                     message_id=excluded.message_id,metric=excluded.metric""",
                  (interaction.guild_id, interaction.channel_id, message.id, metric.value))
    await interaction.followup.send("Permanent leaderboard created/refreshed. Run this command again whenever you want to refresh it.", ephemeral=True)


@bot.tree.command(name="admin_set", description="Admin: change a supported bot setting.")
@admin_only()
@app_commands.choices(key=[
    app_commands.Choice(name="Payday cooldown seconds", value="payday_cooldown"),
])
async def admin_set(interaction: discord.Interaction, key: app_commands.Choice[str], value: app_commands.Range[int, 60, 2592000]):
    set_setting(interaction.guild_id, key.value, str(value))
    await interaction.response.send_message(f"Setting `{key.value}` set to **{value} seconds**.", ephemeral=True)


# Channel restrictions are configured per slash-command name. Administrators can always use commands.
async def channel_permission_check(interaction: discord.Interaction) -> bool:
    if not interaction.guild_id or not interaction.command:
        return True
    if isinstance(interaction.user, discord.Member) and interaction.user.guild_permissions.administrator:
        return True
    channel_id = setting(interaction.guild_id, f"command_channel:{interaction.command.name}")
    if channel_id and str(interaction.channel_id) != channel_id:
        channel = interaction.guild.get_channel(int(channel_id))
        await interaction.response.send_message(
            f"Use `/{interaction.command.name}` in {channel.mention if channel else 'the configured channel'}.", ephemeral=True)
        return False
    return True


bot.tree.interaction_check = channel_permission_check


@bot.tree.command(name="admin_set_command_channel", description="Admin: restrict a slash command to a channel.")
@admin_only()
async def admin_set_command_channel(interaction: discord.Interaction, command_name: str, channel: discord.TextChannel):
    command_name = command_name.strip().lower().lstrip("/")
    if not re.fullmatch(r"[a-z0-9_-]{1,32}", command_name):
        return await interaction.response.send_message("Enter the slash-command name, without `/`.", ephemeral=True)
    set_setting(interaction.guild_id, f"command_channel:{command_name}", str(channel.id))
    await interaction.response.send_message(f"`/{command_name}` is restricted to {channel.mention} (admins bypass this).", ephemeral=True)


@bot.tree.command(name="admin_clear_command_channel", description="Admin: remove a slash command's channel restriction.")
@admin_only()
async def admin_clear_command_channel(interaction: discord.Interaction, command_name: str):
    command_name = command_name.strip().lower().lstrip("/")
    with db() as c:
        c.execute("DELETE FROM settings WHERE guild_id=? AND key=?", (interaction.guild_id, f"command_channel:{command_name}"))
    await interaction.response.send_message(f"Channel restriction cleared for `/{command_name}`.", ephemeral=True)


@bot.tree.command(name="admin_set_declaration_channel", description="Admin: set the channel for automatic declarations.")
@admin_only()
async def admin_set_declaration_channel(interaction: discord.Interaction, channel: discord.TextChannel):
    set_setting(interaction.guild_id, "declaration_channel_id", str(channel.id))
    await interaction.response.send_message(f"Declarations will be posted in {channel.mention}.", ephemeral=True)


@bot.tree.command(name="admin_set_declaration_message", description="Admin: add/update a declaration template with optional conditions.")
@admin_only()
@app_commands.choices(kind=[
    app_commands.Choice(name="With hunter", value="relapsed"),
    app_commands.Choice(name="No hunter", value="relapsed_no_hunter"),
    app_commands.Choice(name="Admin settled claim", value="admin_hunted"),
])
@app_commands.choices(condition=[
    app_commands.Choice(name="Default", value="default"),
    app_commands.Choice(name="Rank range", value="rank"),
    app_commands.Choice(name="Role", value="role"),
    app_commands.Choice(name="Bounty range", value="bounty"),
    app_commands.Choice(name="Points/score range", value="points"),
])
async def admin_set_declaration_message(interaction: discord.Interaction, kind: app_commands.Choice[str],
                                        template: str, condition: app_commands.Choice[str],
                                        min_value: Optional[app_commands.Range[int, 1, 1000000000]] = None,
                                        max_value: Optional[app_commands.Range[int, 1, 1000000000]] = None,
                                        role: Optional[discord.Role] = None):
    if len(template) > 1800:
        return await interaction.response.send_message("Template must be 1,800 characters or fewer.", ephemeral=True)
    if condition.value == "role" and role is None:
        return await interaction.response.send_message("Choose a role for the Role condition.", ephemeral=True)
    if condition.value in ("rank", "bounty", "points") and min_value is None and max_value is None:
        return await interaction.response.send_message("Set at least a minimum or maximum for this condition.", ephemeral=True)
    with db() as c:
        c.execute("INSERT INTO declaration_rules(guild_id,kind,condition_type,min_value,max_value,role_id,template) VALUES(?,?,?,?,?,?,?)",
                  (interaction.guild_id, kind.value, condition.value, min_value, max_value, role.id if role else None, template))
    await interaction.response.send_message(
        "Declaration template saved. Variables: `{relapsed}`, `{hunted}`, `{hunter}`, `{bounty}`, `{points}`, `{rank}`. "
        "Priority is rank > role > bounty/points range > default.", ephemeral=True)


@bot.tree.command(name="admin_clear_declaration_messages", description="Admin: delete all declaration templates for one event type.")
@admin_only()
@app_commands.choices(kind=[
    app_commands.Choice(name="With hunter", value="relapsed"),
    app_commands.Choice(name="No hunter", value="relapsed_no_hunter"),
    app_commands.Choice(name="Admin settled claim", value="admin_hunted"),
])
async def admin_clear_declaration_messages(interaction: discord.Interaction, kind: app_commands.Choice[str]):
    with db() as c:
        c.execute("DELETE FROM declaration_rules WHERE guild_id=? AND kind=?", (interaction.guild_id, kind.value))
    await interaction.response.send_message(f"Cleared all `{kind.value}` declaration templates.", ephemeral=True)


async def publish_declaration(guild: discord.Guild, target: discord.Member, hunter: Optional[discord.Member], bounty: int, kind: str):
    channel_id = setting(guild.id, "declaration_channel_id")
    channel = guild.get_channel(int(channel_id)) if channel_id.isdigit() else None
    if not isinstance(channel, discord.TextChannel):
        return
    target_data = get_user(guild.id, target.id)
    rank_rows = leaderboard_rows(guild.id, "score", 100000)
    rank = next((i + 1 for i, r in enumerate(rank_rows) if r["user_id"] == target.id), len(rank_rows) + 1)
    points = target_data["score"]
    with db() as c:
        rules = c.execute("SELECT * FROM declaration_rules WHERE guild_id=? AND kind=?", (guild.id, kind)).fetchall()
    target_roles = {r.id for r in target.roles}
    def matches(r):
        ct = r["condition_type"]
        if ct == "default": return True
        if ct == "role": return r["role_id"] in target_roles
        value = rank if ct == "rank" else bounty if ct == "bounty" else points
        return (r["min_value"] is None or value >= r["min_value"]) and (r["max_value"] is None or value <= r["max_value"])
    applicable = [r for r in rules if matches(r)]
    priority = {"rank": 0, "role": 1, "bounty": 2, "points": 2, "default": 3}
    applicable.sort(key=lambda r: (priority.get(r["condition_type"], 4), -r["id"]))
    template = applicable[0]["template"] if applicable else (
        "{relapsed} relapsed; {hunter} claimed the bounty of **{bounty:,}**." if hunter else
        "{relapsed} relapsed without a hunter. Bounty: **{bounty:,}**.")
    text = template.replace("{relapsed}", target.mention).replace("{hunted}", target.mention)
    text = text.replace("{hunter}", hunter.mention if hunter else "No hunter").replace("{bounty:,}", f"{bounty:,}").replace("{bounty}", f"{bounty:,}")
    text = text.replace("{points}", f"{points:,}").replace("{rank}", str(rank))
    try: await channel.send(text, allowed_mentions=discord.AllowedMentions(users=True, roles=False, everyone=False))
    except discord.HTTPException as e: print("Declaration send failed:", repr(e))


@bot.tree.command(name="admin_hunted", description="Admin: settle a bounty claim for a target and hunter.")
@admin_only()
async def admin_hunted(interaction: discord.Interaction, target: discord.Member, hunter: Optional[discord.Member] = None):
    data = get_user(interaction.guild_id, target.id)
    if data["hunted"]:
        return await interaction.response.send_message("That member is already settled.", ephemeral=True)
    if hunter and (hunter.bot or hunter.id == target.id):
        return await interaction.response.send_message("Hunter must be another human member.", ephemeral=True)
    claimed = data["bounty"]
    if hunter and claimed <= 0:
        return await interaction.response.send_message("Target has no bounty to claim.", ephemeral=True)
    with db() as c:
        if hunter:
            c.execute("UPDATE users SET bounty=0,hunted=1,hunted_by=? WHERE guild_id=? AND user_id=?",
                      (hunter.id, interaction.guild_id, target.id))
            c.execute("UPDATE users SET score=score+?,hunt_count=hunt_count+1 WHERE guild_id=? AND user_id=?", (claimed, interaction.guild_id, hunter.id))
        else:
            c.execute("UPDATE users SET bounty=0,hunted=1,hunted_by=NULL WHERE guild_id=? AND user_id=?", (interaction.guild_id, target.id))
    await publish_declaration(interaction.guild, target, hunter, claimed, "admin_hunted")
    await refresh_roles_for(interaction.guild, target.id)
    if hunter: await refresh_roles_for(interaction.guild, hunter.id)
    await update_saved_leaderboard(interaction.guild)
    await interaction.response.send_message(f"Settled {target.mention}; bounty was **{claimed:,}**." + (f" Hunter: {hunter.mention}." if hunter else " No hunter involved."), ephemeral=True)


@bot.tree.command(name="admin_set_base_bounty", description="Admin: set the default starting bounty for new members.")
@admin_only()
async def admin_set_base_bounty(interaction: discord.Interaction, amount: app_commands.Range[int, 0, 1000000000]):
    set_setting(interaction.guild_id, "base_bounty", str(amount))
    await interaction.response.send_message(f"Base bounty set to **{amount:,}** for future members.", ephemeral=True)


@bot.tree.command(name="admin_faction_create", description="Admin: create a faction.")
@admin_only()
async def admin_faction_create(interaction: discord.Interaction, name: str, leader: discord.Member):
    name = name.strip()[:50]
    if not name: return await interaction.response.send_message("Faction name cannot be empty.", ephemeral=True)
    try:
        with db() as c: c.execute("INSERT INTO factions(guild_id,name,leader_id) VALUES(?,?,?)", (interaction.guild_id, name, leader.id))
    except sqlite3.IntegrityError:
        return await interaction.response.send_message("That faction already exists.", ephemeral=True)
    await interaction.response.send_message(f"Faction **{name}** created; leader: {leader.mention}.", ephemeral=True)


@bot.tree.command(name="faction_join", description="Join an existing faction.")
async def faction_join(interaction: discord.Interaction, name: str):
    with db() as c: faction = c.execute("SELECT name FROM factions WHERE guild_id=? AND name=? COLLATE NOCASE", (interaction.guild_id, name)).fetchone()
    if not faction: return await interaction.response.send_message("Faction not found.", ephemeral=True)
    with db() as c: c.execute("UPDATE users SET faction=? WHERE guild_id=? AND user_id=?", (faction["name"], interaction.guild_id, interaction.user.id))
    await interaction.response.send_message(f"You joined **{faction['name']}**.")


@bot.tree.command(name="faction_leave", description="Leave your current faction.")
async def faction_leave(interaction: discord.Interaction):
    with db() as c: c.execute("UPDATE users SET faction=NULL WHERE guild_id=? AND user_id=?", (interaction.guild_id, interaction.user.id))
    await interaction.response.send_message("You left your faction.", ephemeral=True)


@bot.tree.command(name="faction", description="View faction membership and totals.")
@app_commands.describe(name="Faction name; omit to view your own faction")
async def faction(interaction: discord.Interaction, name: Optional[str] = None):
    own = get_user(interaction.guild_id, interaction.user.id)["faction"]
    name = name or own
    if not name: return await interaction.response.send_message("You are not in a faction. Use `/faction_join`.", ephemeral=True)
    with db() as c:
        members = c.execute("SELECT user_id,money,bounty,score FROM users WHERE guild_id=? AND faction=? ORDER BY score DESC", (interaction.guild_id, name)).fetchall()
    if not members: return await interaction.response.send_message("Faction not found or has no members.", ephemeral=True)
    lines = [f"<@{r['user_id']}> — {r['score']:,} points | bounty {r['bounty']:,}" for r in members[:25]]
    await interaction.response.send_message(embed=discord.Embed(title=f"Faction: {name}", description="\n".join(lines), color=discord.Color.blurple()))


@tasks.loop(seconds=60)
async def leaderboard_auto_refresh():
    for guild in bot.guilds:
        await update_saved_leaderboard(guild)
        # Keep rank-based roles accurate as scores change.
        with db() as c:
            has_rank_rules = c.execute("SELECT 1 FROM threshold_roles WHERE guild_id=? AND metric='rank' LIMIT 1", (guild.id,)).fetchone()
        if has_rank_rules:
            for member in guild.members:
                if not member.bot:
                    await sync_roles(member)


@leaderboard_auto_refresh.before_loop
async def before_leaderboard_auto_refresh():
    await bot.wait_until_ready()


@bot.tree.command(name="admin_help", description="Admin: list the bot's configuration commands.")
@admin_only()
async def admin_help(interaction: discord.Interaction):
    text = (
        "`/admin_role_reward role payday_money one_time_money` — role salary and one-time bonus\n"
        "`/admin_joker_create name multiplier cost` — create a joker\n"
        "`/admin_joker_give member name quantity` — give joker items\n"
        "`/admin_set_hunted_role role` — role applied after bounty claim\n"
        "`/admin_threshold_role metric threshold role` — automatic score/bounty/hunt-count/rank roles\n"
        "`/admin_remove_threshold_role metric threshold role` — remove a rule\n"
        "`/admin_give_money member amount` — grant money\n"
        "`/admin_set_bounty member amount` — set bounty if not permanently locked\n"
        "`/admin_leaderboard_refresh metric` — create/update permanent leaderboard\n"
        "`/admin_set key value` — change supported settings\n"
        "`/admin_reset_claimed member` — exceptional recovery; bounty remains 0\n"
        "`/admin_set_command_channel command_name channel` / `/admin_clear_command_channel command_name` — channel restrictions\n"
        "`/admin_set_declaration_channel channel` — declaration destination\n"
        "`/admin_set_declaration_message kind template condition [min_value] [max_value] [role]` — custom declaration\n"
        "`/admin_hunted target [hunter]` — admin settlement\n"
        "`/admin_set_base_bounty amount` — default bounty for new members\n"
        "`/admin_faction_create name leader`, `/faction_join name`, `/faction_leave`, `/faction` — factions"
    )
    await interaction.response.send_message(text, ephemeral=True)


@bot.tree.error
async def on_app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    if isinstance(error, app_commands.MissingPermissions):
        message = "You need Discord Administrator permission to use that command."
    elif isinstance(error, app_commands.CommandOnCooldown):
        message = "That command is on cooldown."
    else:
        print("Slash command error:", repr(error))
        message = "Something went wrong. Check the bot console for details."
    if interaction.response.is_done():
        await interaction.followup.send(message, ephemeral=True)
    else:
        await interaction.response.send_message(message, ephemeral=True)


if not TOKEN:
    raise RuntimeError("Set the DISCORD_TOKEN environment variable before starting the bot.")
init_db()
bot.run(TOKEN)
